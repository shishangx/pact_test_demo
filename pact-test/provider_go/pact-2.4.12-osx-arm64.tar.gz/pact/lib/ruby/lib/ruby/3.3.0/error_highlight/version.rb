module ErrorHighlight
  VERSION = "0.6.0"
end
