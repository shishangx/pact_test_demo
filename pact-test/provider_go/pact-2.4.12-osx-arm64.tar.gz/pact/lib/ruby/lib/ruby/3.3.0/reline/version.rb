module Reline
  VERSION = '0.5.7'
end
